#!/usr/bin/env bash
export DJANGO_SETTINGS_MODULE=mybook.settings